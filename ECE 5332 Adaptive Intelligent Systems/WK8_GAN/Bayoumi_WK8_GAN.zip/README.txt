This is Ahmed Bayoumi's attempt at ECE 5332 Adaptive Intelligent Systems Workshop #8 - GAN.

Files:
Bayoumi_WK8_GAN - implementation of the GAN using MATLAB's public example & dataset
initializeGlorot, initializeZeros, projectAndReshapeLayer - functions and extra files needed for the MATLAB example
TrainGenerativeAdversarialNetworkGANExample - the MATLAB example
results_ss - a screenshot of the results

Results:
training couldn't converge due to a connection error, but results so far were screenshot